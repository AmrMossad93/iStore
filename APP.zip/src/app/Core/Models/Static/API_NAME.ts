export const API_NAME = {
  catalogue: {
    list: 'esb/catalogues'
  },
  products: {
    listByCatalogueId: 'esb/products'
  }
}
